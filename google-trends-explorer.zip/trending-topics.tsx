"use client"

import { useState } from "react"
import {
  ArrowUp,
  BarChart2,
  ExternalLink,
  Sparkles,
  TrendingUp,
  LineChart,
  FlameIcon as Fire,
  Star,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Skeleton } from "@/components/ui/skeleton"

export function TrendingTopics() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null)

  // Mock data - replace with actual API data
  const trends = [
    {
      id: 1,
      topic: "Inteligencia Artificial en 2024",
      category: "Tecnología",
      searches: "2.5M",
      growth: "+125%",
      relatedTopics: ["Machine Learning", "ChatGPT", "Automatización"],
      trend: "up",
      interest: 95,
    },
    {
      id: 2,
      topic: "Energías Renovables",
      category: "Ciencia",
      searches: "1.8M",
      growth: "+85%",
      relatedTopics: ["Solar", "Eólica", "Sostenibilidad"],
      trend: "up",
      interest: 82,
    },
    {
      id: 3,
      topic: "Trabajo Remoto",
      category: "Negocios",
      searches: "1.2M",
      growth: "+45%",
      relatedTopics: ["Productividad", "Herramientas Colaborativas", "Balance vida-trabajo"],
      trend: "up",
      interest: 78,
    },
  ]

  const handleGenerateArticle = async (topic: string) => {
    setSelectedTopic(topic)
    setIsGenerating(true)
    // Simulate API call
    setTimeout(() => {
      setIsGenerating(false)
    }, 2000)
  }

  const getTrendIcon = (interest: number) => {
    if (interest >= 90) return <Fire className="w-5 h-5 text-red-500" />
    if (interest >= 80) return <TrendingUp className="w-5 h-5 text-orange-500" />
    return <Star className="w-5 h-5 text-yellow-500" />
  }

  return (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {trends.map((trend) => (
          <Card key={trend.id} className="flex flex-col relative overflow-hidden">
            <div className="absolute right-0 top-0 p-4">{getTrendIcon(trend.interest)}</div>
            <CardHeader>
              <div className="flex items-start gap-2">
                <CardTitle className="text-lg font-semibold">{trend.topic}</CardTitle>
              </div>
              <Badge variant="secondary" className="mt-2 w-fit">
                {trend.category}
              </Badge>
            </CardHeader>
            <CardContent className="flex-1 grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1">
                  <span className="text-sm text-muted-foreground">Búsquedas</span>
                  <div className="flex items-center gap-2">
                    <BarChart2 className="w-4 h-4 text-muted-foreground" />
                    <span className="font-semibold">{trend.searches}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-sm text-muted-foreground">Crecimiento</span>
                  <div className="flex items-center gap-2 text-green-600">
                    <ArrowUp className="w-4 h-4" />
                    <span className="font-semibold">{trend.growth}</span>
                  </div>
                </div>
              </div>

              <div className="h-[60px] flex items-center justify-center bg-muted rounded-md">
                <LineChart className="w-[100px] h-[40px] text-primary" />
              </div>

              <div className="space-y-2">
                <span className="text-sm text-muted-foreground">Temas relacionados</span>
                <div className="flex flex-wrap gap-2">
                  {trend.relatedTopics.map((topic) => (
                    <Badge key={topic} variant="outline">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 mt-auto">
                <Button variant="outline" className="w-full">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Ver detalles
                </Button>
                <Button className="w-full" onClick={() => handleGenerateArticle(trend.topic)}>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generar Artículo
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isGenerating} onOpenChange={() => setIsGenerating(false)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              Generando Artículo
            </DialogTitle>
            <DialogDescription>
              Generando un artículo optimizado basado en las tendencias actuales para: {selectedTopic}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Skeleton className="h-4 w-[250px]" />
              <Skeleton className="h-4 w-[200px]" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-[300px]" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-4 w-[250px]" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

