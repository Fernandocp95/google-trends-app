import { OpenAIStream, StreamingTextResponse } from "ai"
import OpenAI from "openai"

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  const { topic } = await req.json()

  const prompt = `
    Genera un artículo optimizado para SEO sobre el tema: "${topic}".
    El artículo debe incluir:
    - Un título atractivo
    - Una introducción cautivadora
    - 3-4 secciones principales
    - Conclusión
    - Palabras clave relevantes
    - Tono informativo y profesional
    - Longitud aproximada: 800 palabras
  `

  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "Eres un experto en redacción de contenido SEO y análisis de tendencias.",
      },
      {
        role: "user",
        content: prompt,
      },
    ],
    stream: true,
  })

  const stream = OpenAIStream(response)
  return new StreamingTextResponse(stream)
}

