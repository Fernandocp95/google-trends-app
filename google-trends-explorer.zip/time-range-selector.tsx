"use client"

import { CalendarDays, Clock, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useState } from "react"

export function TimeRangeSelector() {
  const [selectedRange, setSelectedRange] = useState("daily")

  return (
    <Card className="p-4">
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedRange === "daily" ? "default" : "outline"}
          onClick={() => setSelectedRange("daily")}
          className="flex items-center gap-2"
        >
          <Clock className="w-4 h-4" />
          Diario
        </Button>
        <Button
          variant={selectedRange === "weekly" ? "default" : "outline"}
          onClick={() => setSelectedRange("weekly")}
          className="flex items-center gap-2"
        >
          <CalendarDays className="w-4 h-4" />
          Semanal
        </Button>
        <Button
          variant={selectedRange === "monthly" ? "default" : "outline"}
          onClick={() => setSelectedRange("monthly")}
          className="flex items-center gap-2"
        >
          <Calendar className="w-4 h-4" />
          Mensual
        </Button>
      </div>
    </Card>
  )
}

