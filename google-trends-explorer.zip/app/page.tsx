"use client"

import TrendsExplorer from "../page"

export default function SyntheticV0PageForDeployment() {
  return <TrendsExplorer />
}