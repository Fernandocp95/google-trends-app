import { TrendingTopics } from "./trending-topics"
import { TimeRangeSelector } from "./time-range-selector"
import { SearchFilters } from "./search-filters"

export default function TrendsExplorer() {
  return (
    <div className="container mx-auto p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold tracking-tight">Explorador de Tendencias</h1>
        <p className="text-muted-foreground">
          Descubre tendencias populares y obtén ideas para contenido basadas en el interés del público
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-[300px_1fr]">
        <aside className="space-y-4">
          <SearchFilters />
        </aside>

        <main className="space-y-6">
          <TimeRangeSelector />
          <TrendingTopics />
        </main>
      </div>
    </div>
  )
}

